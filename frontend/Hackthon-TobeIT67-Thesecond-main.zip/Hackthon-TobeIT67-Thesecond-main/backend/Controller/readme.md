only controller no logic at here!

using

express.js

